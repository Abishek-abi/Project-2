<?php
$name = filter_input(INPUT_POST, 'name');
$email = filter_input(INPUT_POST, 'email');
$phone = filter_input(INPUT_POST, 'phone');
$message = filter_input(INPUT_POST, 'message');
if (!empty($name)){
if (!empty($email)){
if(!empty($message)){
if(!empty($phone)){
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "test";
// Create connection
$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
if (mysqli_connect_error()){
die('Connect Error ('. mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else{
$sql = "INSERT INTO contactus (ContactName, ContactEmail, ContactPhone, Message)
values ('$name','$email','$phone','$message' )";
if ($conn->query($sql)){
echo "Successfully send an enqiury";
}
else{
echo "Error: ". $sql ."
". $conn->error;
}
$conn->close();
}
}
else{
    echo "Phone should not be empty";
    die();
    }
}
else{
    echo "Message should not be empty";
    die();
    }
}
else{
    echo "Email should not be empty";
    die();
    }

}

else{
echo "Name should not be empty";
die();
}
?>